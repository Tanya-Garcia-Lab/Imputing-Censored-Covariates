library(testthat)
library(imputeCensoRd)

test_check("imputeCensoRd")
